/* eslint-disable complexity */
import { trimByLength } from '../helpers/trim-by-length'
import { getCookie } from '../helpers/cookie'
import type { PreparedProperties, Properties } from '../helpers/property.types'
import { updateCustomIdentifiers } from '../helpers/update-custom-identifiers'
import { HashableUpdater, hashByConfig, HashableUpdaterByKey } from '../helpers/hash-by-config'
import { PROFILE_COOKIE_NAMES } from '../config/constants'
import { getUTMUrlProperties } from '../helpers/get-utm-url-params'

import { updateExistingPackages } from './package-storage'

const APPLICATION_LANGUAGE_LENGTH = 16
const CLIENT_BLOCK_LENGTH = 64
const APP_VERSION_LENGTH = 50
const APP_VERSION_NUMBER_LENGTH = 32

/**
 * Структура настроек профиля для пакета событий
 */
export interface Profile {
    /** Номер блока, если веб-приложение имеет блочную архитектуру */
    clientBlock?: string
    /**
   * Уникальный идентификатор пользователя вашего приложения (при необходимости можно передавать хэш).
   * Примеры: СБОЛ передает хэш от ЕРИБ логин, Сбермейзинг - табельный номер сотрудника
   * обязательный параметр
   */
    hashUserLoginId?: string
    /**
    * Для МП: Заполняется приложением
    */
    appBuild?: string
    /**
    * Application store distributor name
    */
    appDistributor?: string
    /**
    * Версия приложения
    */
    appVersion?: string
    /**
    * Номер версии приложения
    */
    appVersionNumber?: string
    /**
   * Используется только во внутреннем продукте СБОЛ.ПРО. Внешние сервисы не смогут принять метрики с этими параметрами
   */
    adId?: string
    /**
   * Используется только во внутреннем продукте СБОЛ.ПРО. Внешние сервисы не смогут принять метрики с этими параметрами
   */
    appId?: string
    /**
   * Используется только во внутреннем продукте СБОЛ.ПРО. Внешние сервисы не смогут принять метрики с этими параметрами
   */
    subId?: string
    /**
   * Используется только во внутреннем продукте СБОЛ.ПРО. Внешние сервисы не смогут принять метрики с этими параметрами
   */
    sapId?: string
    /**
   * Используется только во внутреннем продукте СБОЛ.ПРО. Внешние сервисы не смогут принять метрики с этими параметрами
   */
    partnerId?: string
}

/**
* Блок данных о клиенте
*/
export interface FilledProfile extends Profile {
    /**
     * Значение, позволяющее однозначно определить пару устройство-браузер пользователя
     */
    deviceId?: string
    /**
     * Значение, позволяющее однозначно определить сессию пользователя
     */
    sessionId?: string
    /**
     * Язык приложения
     */
    applicationLanguage?: string
    /**
     * Куки смежных аналитик
     */
    cookie?: PreparedProperties
    /**
     * Набор дополнительных идентификаторов
     */
    customIdentifiers?: Properties
    /**
     * Набор внешних маркетинговых параметров URL
     */
    utm?: Properties
}

const profile: FilledProfile = {}

export const getProfileCookie = (): FilledProfile['cookie'] => {
    const result: FilledProfile['cookie'] = []

    PROFILE_COOKIE_NAMES.forEach((cookieName) => {
        const value = getCookie(cookieName)
        if (value) {
            result.push({ key: cookieName, value: trimByLength(value) })
        }
    })

    return result.length > 0 ? result : void 0
}

/**
 * Установка настроек профиля для пакета событий
 * @param {Profile} nextProfile объект настроек профиля
 * @return {void}
 */
export const setProfile = (nextProfile: Profile): void => {
    Object.assign(profile, {
        ...nextProfile,
        ...nextProfile.clientBlock && { clientBlock: trimByLength(nextProfile.clientBlock, CLIENT_BLOCK_LENGTH) },
        ...nextProfile.hashUserLoginId && { hashUserLoginId: trimByLength(nextProfile.hashUserLoginId) },
        ...nextProfile.appVersion && { appVersion: trimByLength(nextProfile.appVersion, APP_VERSION_LENGTH) },
        ...nextProfile.appBuild && { appBuild: trimByLength(nextProfile.appBuild) },
        ...nextProfile.appDistributor && { appDistributor: trimByLength(nextProfile.appDistributor) },
        ...nextProfile.appVersionNumber && { appVersionNumber: trimByLength(nextProfile.appVersionNumber, APP_VERSION_NUMBER_LENGTH) },
        ...nextProfile.adId && { adId: trimByLength(nextProfile.adId) },
        ...nextProfile.appId && { appId: trimByLength(nextProfile.appId) },
        ...nextProfile.subId && { subId: trimByLength(nextProfile.subId) },
        ...nextProfile.sapId && { sapId: trimByLength(nextProfile.sapId) },
        ...nextProfile.partnerId && { partnerId: trimByLength(nextProfile.partnerId) }
    })

    // Обновляем профиль в уже сформированных пакетах
    updateExistingPackages({ profile })
}

interface ProfileUpdater {
    setEmail: HashableUpdater<this>
    setPhone: HashableUpdater<this>
    setSbClID: HashableUpdater<this>
    setClientID: HashableUpdater<this>
    setProfileID: HashableUpdaterByKey<this>
}

/**
 * Совокупность методов установки специфичных параметров профиля
 */
export const profileUpdater: ProfileUpdater = {
    /**
     * Установка email клиента
     * @param {String} value значение email
     * @param {Boolean} enableHash признак хэширования
     * @return {ProfileUpdater} profileUpdater
     */
    setEmail (value, enableHash) {
        updateCustomIdentifiers({
            entity: profile,
            key: 'email',
            value: hashByConfig(value, enableHash)
        })
        return this
    },
    /**
     * Установка phone number клиента
     * @param {String} value значение phone number
     * @param {Boolean} enableHash признак хэширования
     * @return {ProfileUpdater} profileUpdater
     */
    setPhone (value, enableHash) {
        updateCustomIdentifiers({
            entity: profile,
            key: 'phoneNumber',
            value: hashByConfig(value, enableHash)
        })
        return this
    },
    /**
     * Установка sbClientId клиента
     * @param {String} value значение sbClientId
     * @param {Boolean} enableHash признак хэширования
     * @return {ProfileUpdater} profileUpdater
     */
    setSbClID (value, enableHash) {
        updateCustomIdentifiers({
            entity: profile,
            key: 'sbClientId',
            value: hashByConfig(value, enableHash)
        })
        return this
    },
    /**
     * Установка ClientId клиента
     * @param {String} value значение ClientId
     * @param {Boolean} enableHash признак хэширования
     * @return {ProfileUpdater} profileUpdater
     */
    setClientID (value, enableHash) {
        profile.hashUserLoginId = hashByConfig(value, enableHash)
        return this
    },
    /**
     * Установка значения некоторого идентификатора в profile
     * @param {String} key ключ идентификатора
     * @param {String} value значение идентификатора
     * @param {Boolean} enableHash признак хэширования
     * @return {MetaUpdater} metaUpdater
     */
    setProfileID (key, value, enableHash) {
        updateCustomIdentifiers({
            entity: profile,
            key,
            value: hashByConfig(value, enableHash)
        })
        return this
    }
}

export const getProfile = ({
    sessionId,
    deviceId
}: {
    sessionId?: string
    deviceId?: string
}): FilledProfile => {
    const cookie = getProfileCookie()
    const utm = getUTMUrlProperties()

    return {
        ...profile,
        applicationLanguage: trimByLength(globalThis.document?.documentElement.lang, APPLICATION_LANGUAGE_LENGTH),
        deviceId,
        sessionId,
        ...cookie && { cookie },
        ...utm && { utm }
    }
}
