const VALUES_IN_BYTE = 256
const UUIDV4_PATTERN = '10000000-1000-4000-8000-100000000000'
const STRING_HEX_VIEW = 16

const SHIFTED_VALUE = 15
const UUID_DIVIDER = 4

const cryptoMock = {
    getRandomValues: (array: Uint8Array): Uint8Array => {
        const filledArr = new Uint8Array([...array])
        for (let i = 0; i < filledArr.length; i += 1) {
            filledArr[i] = Math.floor(Math.random() * VALUES_IN_BYTE)
        }
        return filledArr
    }
}
// comment: В IE11 crypto за флагом ms, условие минимальное, чтобы разделять его по типам сборок
// eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
const crypto = globalThis.crypto ?? globalThis.msCrypto ?? cryptoMock

const replacer = (c: string): string => {
    const num = Number(c)
    const randomValue = Number(crypto.getRandomValues(new Uint8Array(1))[0])
    /* comment: манипуляция битами необходима для создания псевдослучайного числа */
    /* eslint-disable-next-line no-bitwise */
    return (num ^ (randomValue & (SHIFTED_VALUE >> (num / UUID_DIVIDER))))
        .toString(STRING_HEX_VIEW)
}

export const uuidv4 = (): string => {
    return UUIDV4_PATTERN.replace(/[018]/g, replacer)
}
