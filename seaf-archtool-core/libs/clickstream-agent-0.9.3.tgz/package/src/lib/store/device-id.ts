import { getTimestamp } from '../getters/get-time-stamp'
import { uuidv4 } from '../helpers/uuid'
import { Request } from '../helpers/send-package'
import { getDeviceIdUrl, getUserIdentifiersStore } from '../config/config'
import { requestFetch } from '../adapters/fetch'

import { scheduleFirstLaunchEvent } from './schedule-tech-events'

const DEVICE_KEY = '_sv'
const LOCAL_DEVICE_KEY = '_sa'
const PREFIX = 'SA'
const VERSION = '1'
// 30 дней в миллисекундах
const DEVICE_ID_RECHECK_TIMEOUT = 2592000000

let promiseDeviceId: Promise<void> | null = null

/**
 * Инициализация установки deviceId
 * @param {String} deviceIdUrl адрес получения deviceId
 * @param {Request} requestAdapter сетевой адаптер
 * @return {void}
 */
export const setDeviceId = async (deviceIdUrl: string, requestAdapter: Request): Promise<void> => {
    const userIdentifiersStore = getUserIdentifiersStore()
    if (await userIdentifiersStore.getData(DEVICE_KEY)) {
        return void 0
    }
    if (promiseDeviceId) {
        return promiseDeviceId
    }
    promiseDeviceId = requestAdapter({
        url: deviceIdUrl,
        method: 'GET',
        credentials: true
    })
        .then(async (response: { id: string }) => {
            if (typeof response?.id !== 'string') {
                throw new TypeError('request to deviceIdUrl not return id')
            }
            const deviceId = response.id
            await userIdentifiersStore.setData(
                DEVICE_KEY,
                deviceId,
                DEVICE_ID_RECHECK_TIMEOUT
            )
            void scheduleFirstLaunchEvent(deviceId)
            return void 0
        })
    return promiseDeviceId
}

const setLocalDeviceId = async (): Promise<void> => {
    const userIdentifiersStore = getUserIdentifiersStore()
    const currentLocalValue = await userIdentifiersStore.getData(LOCAL_DEVICE_KEY)

    if (!currentLocalValue) {
        const uuid = uuidv4()
        const localValue = `${PREFIX}${VERSION}.${uuid}.${String(getTimestamp())}`
        await userIdentifiersStore.setData(LOCAL_DEVICE_KEY, localValue, DEVICE_ID_RECHECK_TIMEOUT)

        void scheduleFirstLaunchEvent(localValue)
    }
    return void 0
}

/**
 * Получение ранее запрощенного deviceId, если deviceId не был получен, создаем его локально
 * @return {Promise<String>} deviceId
 */
export const getDeviceId = async (): Promise<string | undefined> => {
    const userIdentifiersStore = getUserIdentifiersStore()
    let globalDeviceId = await userIdentifiersStore.getData(DEVICE_KEY)

    if (!globalDeviceId) {
        try {
            await setDeviceId(getDeviceIdUrl(), requestFetch)
            globalDeviceId = await userIdentifiersStore.getData(DEVICE_KEY)
        } catch (e: unknown) {
            /* Если не установили cookie по причине отсутствия url или его неработоспособности */
            await setLocalDeviceId()
            globalDeviceId = await userIdentifiersStore.getData(LOCAL_DEVICE_KEY)
        }
    }
    return globalDeviceId
}
