import { flushStorage } from './package-storage'
import { setSessionId } from './session-id'

export const flushFullStorage = (): void => {
    if (document.visibilityState === 'hidden') {
        void setSessionId().then(() => {
            flushStorage(true)
            return void 0
        })
    }
}
