import { PreparedProperties, Properties } from './property.types'
import { trimByLength } from './trim-by-length'

const UTM_PARAMS_MAX_LENGTH = 32

export const getUTMUrlProperties = (): Properties => {
    const result: PreparedProperties = []

    if (!globalThis.location) {
        return null
    }

    const searchParams = new URLSearchParams(globalThis.location.search)

    if (searchParams.size === 0) {
        return null
    }

    searchParams.forEach((paramValue, paramName) => {
        if (paramValue) {
            result.push({ key: paramName, value: trimByLength(paramValue) })
        }
    })

    if (result.length === 0) {
        return null
    }

    return result.slice(0, UTM_PARAMS_MAX_LENGTH)
}
