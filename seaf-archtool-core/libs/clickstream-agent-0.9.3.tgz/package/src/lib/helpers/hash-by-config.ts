import { getHashSalt, getHashAlgorithm } from '../config/config'

import { trimByLength } from './trim-by-length'

export type HashableUpdater<T> = (value: string, enableHash?: boolean) => T

export type HashableUpdaterByKey<T> = (key: string, value: string, enableHash?: boolean) => T

export type CreateHash = (value: string, salt?: string) => string

export const hashByConfig: HashableUpdater<string> = (value, enableHash = false) => {
    const trimmedValue = trimByLength(value)
    const hashAlgorithm = getHashAlgorithm()
    const hashSalt = getHashSalt()

    if (hashAlgorithm && enableHash) {
        return hashAlgorithm(trimmedValue, hashSalt)
    }

    return trimmedValue
}
