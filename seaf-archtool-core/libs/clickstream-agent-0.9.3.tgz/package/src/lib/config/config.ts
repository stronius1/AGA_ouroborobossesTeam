import type { Request } from '../helpers/send-package'
import type { CreateHash } from '../helpers/hash-by-config'
import { UserIdentifiersStore, userIdentifiersStoreCookie } from '../store/user-identifiers-store'

import { setRequestAdapter, setRestRequestAdapter } from './config-adapters'
import { DEVICE_ID_URL } from './constants'

const DEFAULT_BUFFER_SIZE = 10
const DEFAULT_SESSION_LIFETIME = 600000

const isNaturalNumber = (number: number): boolean => {
    return Number.isFinite(number) && Number.isInteger(number) && number > 0
}

let configBufferSize = DEFAULT_BUFFER_SIZE
let configReportUrl = ''
const configDeviceIdUrl = DEVICE_ID_URL
let configHashAlgorithm: CreateHash
let configUserIdentifiersStore = userIdentifiersStoreCookie
let configHashSalt = ''
let configSessionLifetime = DEFAULT_SESSION_LIFETIME

/**
 * Установка размера пакета событий в сетевом запросе
 * @param {Number} bufferSize количество элементов в массиве body.data
 * @return {void}
 */
export const setBufferSize = (bufferSize: number): void => {
    if (isNaturalNumber(bufferSize)) {
        configBufferSize = bufferSize
    }
}
export const getBufferSize = (): number => {
    return configBufferSize
}

/**
 * Установка адреса для отправки метрик
 * @param {String} reportUrl адрес для отправки метрик
 * @return {void}
 */
export const setReportUrl = (reportUrl: string): void => {
    configReportUrl = reportUrl
}
export const getReportUrl = (): string => {
    return configReportUrl
}

/**
 * @deprecated Адрес для deviceId устанавливается самостоятельно
 * Установка адреса для получения deviceId. Метод пытается сразу же получить deviceId
 * @param {String} deviceIdUrl адрес для получения deviceId
 * @return {void}
 */
export const setDeviceIdUrl = (deviceIdUrl: string): void => {}
export const getDeviceIdUrl = (): string => {
    return configDeviceIdUrl
}

/**
 * Переопределение алгоритма хэширования
 * @param {CreateHash} hashAlgorithm алгоритм хэширования
 * @return {void}
 */
export const setHashAlgorithm = (hashAlgorithm: CreateHash): void => {
    configHashAlgorithm = hashAlgorithm
}
export const getHashAlgorithm = (): CreateHash => {
    return configHashAlgorithm
}

/**
 * Переопределение соли для алгоритма хэширования
 * @param {String} hashSalt соль для алгоритма хэширования
 * @return {void}
 */
export const setHashSalt = (hashSalt: string): void => {
    configHashSalt = hashSalt
}
export const getHashSalt = (): string => {
    return configHashSalt
}

/**
 * Переопределение времени жизни сессии clickstream
 * @param {Number} sessionLifetime время жизни сессии clickstream, миллисекунд
 * @return {void}
 */
export const setSessionLifetime = (sessionLifetime: number): void => {
    configSessionLifetime = sessionLifetime
}
export const getSessionLifetime = (): number => {
    return configSessionLifetime
}

/**
 * Переопределение места хранения идентификаторов пользователя
 * @param {UserIdentifiersStore} userIdentifiersStore методы для сохранения индетификаторов пользователя
 * @return {void}
 */
export const setUserIdentifiersStore = (userIdentifiersStore: UserIdentifiersStore): void => {
    configUserIdentifiersStore = userIdentifiersStore
}
export const getUserIdentifiersStore = (): UserIdentifiersStore => {
    return configUserIdentifiersStore
}

/**
 * Объект первичных настроек Clickstream
 */
export type Config = {
    /** Адрес для отправки событий */
    reportUrl?: string
    /** Адрес для получения deviceId */
    deviceIdUrl?: string
    /** Количество событий в одном сообщении, значение по умолчанию 10 */
    bufferSize?: number
    /** Adapter для отправки запроса (xhr, fetch, beacon) */
    requestAdapter?: Request
    /** Adapter для отправки последнего запроса (xhr, fetch, beacon) */
    restRequestAdapter?: Request
    /** Переопределение места сохранения идентификации пользователя (id устройства / сессия) */
    userIdentifiersStore?: UserIdentifiersStore
    /** Переопределение алгоритма хэширования */
    hashAlgorithm?: CreateHash
    /** Переопределение соли для алгоритма хэширования */
    hashSalt?: string
    /** Время жизни сессии clickstream в миллисекундах */
    sessionLifetime?: number
}

export { setRequestAdapter, setRestRequestAdapter }

/**
 * Основной метод, определяющий логику работы SDK
 * @param {Config} config параметры настройки Clickstream
 * @return {void}
 */
export const setConfig = ({
    reportUrl,
    deviceIdUrl,
    bufferSize,
    requestAdapter,
    restRequestAdapter,
    userIdentifiersStore,
    hashAlgorithm,
    hashSalt,
    sessionLifetime
}: Config): void => {
    if (reportUrl) {
        setReportUrl(reportUrl)
    }
    if (deviceIdUrl) {
        setDeviceIdUrl(deviceIdUrl)
    }
    if (bufferSize) {
        setBufferSize(bufferSize)
    }
    if (requestAdapter) {
        setRequestAdapter(requestAdapter)
    }
    if (restRequestAdapter) {
        setRestRequestAdapter(restRequestAdapter)
    }
    if (userIdentifiersStore) {
        setUserIdentifiersStore(userIdentifiersStore)
    }
    if (hashAlgorithm) {
        setHashAlgorithm(hashAlgorithm)
    }
    if (hashSalt) {
        setHashSalt(hashSalt)
    }
    if (sessionLifetime) {
        setSessionLifetime(sessionLifetime)
    }
}
