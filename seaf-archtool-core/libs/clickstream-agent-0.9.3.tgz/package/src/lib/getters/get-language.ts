export default (): string => {
    return globalThis.navigator?.language ||
    globalThis.navigator?.userLanguage ||
    globalThis.navigator?.browserLanguage ||
    globalThis.navigator?.systemLanguage ||
    'ru'
}
