declare module 'node-forge/lib/sha256' {
    export default {
        create (): {
            update: (text: string) => undefined
            digest: () => {
                toHex(): string
            }
        }
    }
}
