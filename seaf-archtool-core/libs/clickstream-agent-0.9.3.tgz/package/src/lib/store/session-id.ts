import { getTimestamp } from '../getters/get-time-stamp'
import { getSessionLifetime, getUserIdentifiersStore } from '../config/config'
import { makeSessionIdKey } from '../helpers/make-session-id-key'
import { CUSTOM_SESSION_ID_KEY } from '../config/constants'

import { scheduleStartSessionEvent } from './schedule-tech-events'
import { getDeviceId } from './device-id'
import { getMeta } from './meta'


let promiseSessionId: Promise<void> | null = null

const createSessionId = async (sessionIdKey: string): Promise<void> => {
    const userIdentifiersStore = getUserIdentifiersStore()
    if (await userIdentifiersStore.getData(sessionIdKey)) {
        return void 0
    }
    if (promiseSessionId) {
        return promiseSessionId
    }
    promiseSessionId = getDeviceId()
        .then(async (deviceId) => {
            const sessionId = `${deviceId ?? ''}.${String(getTimestamp())}`
            await userIdentifiersStore.setData(
                sessionIdKey,
                sessionId,
                getSessionLifetime()
            )
        
            const { apiKey } = getMeta()
            // Не отправляем старт сессии без apiKey
            if (apiKey) {
                scheduleStartSessionEvent(sessionId)
            }
            return void 0
        })
        .finally(() => {
            promiseSessionId = null
        })
    return promiseSessionId
}


/**
 * Переопределение sessionId, установленного агентом clickstream
 * Чтобы отменить переопределение, вызовите deleteSessionId()
 * @param {String} value новое сессионное значение
 * @return {void}
 */
export const setSessionId = async (value?: string): Promise<void> => {
    const userIdentifiersStore = getUserIdentifiersStore()
    const customSessionId = await userIdentifiersStore.getData(CUSTOM_SESSION_ID_KEY)
    if (value && customSessionId !== value) {
        // Установка специфичной сессии
        await userIdentifiersStore.setData(
            CUSTOM_SESSION_ID_KEY,
            value,
            getSessionLifetime()
        )

        scheduleStartSessionEvent(value)
    }

    const sessionIdKey = makeSessionIdKey()
    const storedSessionId = customSessionId || await userIdentifiersStore.getData(sessionIdKey)

    if (storedSessionId) {
        // Обновление срока жизни сессии
        await userIdentifiersStore.setData(
            customSessionId ? CUSTOM_SESSION_ID_KEY : sessionIdKey,
            storedSessionId,
            getSessionLifetime()
        )
    } else {
        await createSessionId(sessionIdKey)
    }
}

export const getSessionId = async (): Promise<string | undefined> => {
    const userIdentifiersStore = getUserIdentifiersStore()
    return await userIdentifiersStore.getData(CUSTOM_SESSION_ID_KEY) || userIdentifiersStore.getData(makeSessionIdKey())
}

/**
 * Отмена переопределения sessionId, установленного агентом clickstream
 * @return {void}
 */
export const deleteSessionId = async (): Promise<void> => {
    await getUserIdentifiersStore().deleteData(CUSTOM_SESSION_ID_KEY)
}
