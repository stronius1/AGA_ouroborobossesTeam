import { EventItem } from '../event'
import getOnline from '../getters/get-online'
import { getReportUrl } from '../config/config'
import { getRequestAdapter, getRestRequestAdapter } from '../config/config-adapters'
import type { FilledMeta } from '../store/meta'
import type { FilledProfile } from '../store/profile'
import { LOG_PREFIX } from '../config/constants'

/**
 * Тело запроса для отправки метрик
 */
export interface RequestBody {
    /**
     * Блок данных о приложении, устройстве и пакете отправленных данных
     */
    meta: FilledMeta
    /**
     * Блок данных о клиенте
     */
    profile: FilledProfile
    /**
     * Массив событий в пакете
     */
    data: Array<EventItem>
}

/**
 * Конфиг отправки данных
 */
export interface RequestConfig {
    url: string
    body?: RequestBody
    method?: 'GET' | 'POST'
    credentials?: boolean
}
/**
 * Метод отправки данных
 */
export type Request<T = any> = (config: RequestConfig) => Promise<T>

export const sendPackage = async (event: RequestBody, rest = false): Promise<void> => {
    const requestAdapter = rest ? getRestRequestAdapter() : getRequestAdapter()

    if (!getReportUrl()) {
        throw new Error(`${LOG_PREFIX} reportUrl is not defined`)
    }
    if (!getOnline()) {
        throw new Error(`${LOG_PREFIX} Application is offline`)
    }
    if (!requestAdapter) {
        throw new Error(`${LOG_PREFIX} Adapter is not defined`)
    }

    await requestAdapter({
        url: getReportUrl(),
        body: event,
        method: 'POST'
    })
}
