import { deleteCookie, getCookie, setCookie } from '../helpers/cookie'

/**
 * Интерфейс для перепоределения места хранения данных для идентификации пользователя
 */
export interface UserIdentifiersStore {
    /**
     * Сохранить параметр пользователя по ключу, на указанное время
     * @param name - название параметра
     * @param value - значение
     * @param ms - время на которое надо сохранить
     * @returns void
     */
    setData: (name: string, value: string, ms: number) => Promise<void>

    /**
     * Получить ранее сохраненное значение из хранилища
     * @param name - название параметра
     * @returns ранее переданное value или undefined
     */
    getData: (name: string) => Promise<string | undefined>

    /**
     * Удалить пару ключ-значение из хранилища по ключу
     * @param name ключ для удаления
     * @returns void
     */
    deleteData: (name: string) => Promise<void>
}

/**
 * Хранилище для индетификации пользователя в куках
 */
export const userIdentifiersStoreCookie: UserIdentifiersStore = {
  
    getData (name: string): Promise<string | undefined> {
        return Promise.resolve(getCookie(name))
    },
  
    setData (name: string, value: string, ms: number): Promise<void> {
        setCookie(name, value, ms)
        return Promise.resolve()
    },
  
    deleteData (name: string): Promise<void> {
        deleteCookie(name)
        return Promise.resolve()
    }
  
}
