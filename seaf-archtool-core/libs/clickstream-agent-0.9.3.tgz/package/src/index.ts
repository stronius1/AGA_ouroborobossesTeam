import { preset } from './lib/preset'
import { global } from './lib/global'

// По дефолту устанавливает все необходимые обработчики и глобальное API
// Для самостоятельной настройки SDK, используется импорт clickstream-agent/sdk
preset()
global()

export * from './sdk'
