import { flushFullStorage } from '../store/flush-full-storage'

/**
 * Обработчик переключение вкладки
 * @return {void}
 */
export const hiddenTabHandler = (): void => {
    globalThis.document?.addEventListener('visibilitychange', flushFullStorage)
}
