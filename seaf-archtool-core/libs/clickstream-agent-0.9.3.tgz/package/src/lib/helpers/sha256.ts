import nodeForgeSha256 from 'node-forge/lib/sha256'

import type { CreateHash } from './hash-by-config'

/**
 * алгоритм хэширования sha256
 * @param {String} value значение
 * @param {String} salt соль
 * @return {String} хэш
 */
export const sha256: CreateHash = (value, salt): string => {
    const text = `${value}${salt ?? ''}`
    const md = nodeForgeSha256.create()
    md.update(text)
    return md.digest().toHex()
}
