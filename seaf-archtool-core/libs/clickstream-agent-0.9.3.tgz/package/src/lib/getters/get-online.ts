export default (): boolean => {
    return globalThis.navigator?.onLine ?? true
}
