import getConnectionType from '../getters/get-connection-type'
import getBatteryLevel from '../getters/get-battery-level'
import { getISOTime } from '../getters/get-time-stamp'
import { trimByLength } from '../helpers/trim-by-length'
import { prepareProperties } from '../helpers/prepare-properties'
import { getCurrentTitle, getCurrentURL } from '../helpers/get-document-data'
import type { RequestBody } from '../helpers/send-package'
import type { BaseItem, EventItem } from '../event'

import { getProfile } from './profile'
import { getMeta } from './meta'
import { getDeviceId } from './device-id'
import { getSessionId, setSessionId } from './session-id'

const EVENT_ACTION_LENGTH = 1024

type EventType = 'technical' | 'sensitive' | 'business'

export interface EventDataOptions {
    url?: string
    timeStamp?: string
    sessionId?: string
    deviceId?: string
}

const getData = async (event: BaseItem, eventType: EventType, options?: EventDataOptions): Promise<EventItem> => {
    const url = options?.url ?? getCurrentURL()
    const pageName = getCurrentTitle()
    const { platform } = getMeta()
    const isWebPlatform = platform === 'WEB'

    const eventAction = isWebPlatform
        ? event.eventAction
        : `${event.eventCategory ? `${event.eventCategory}/` : ''}${
            event.eventAction
        }${event.value ? `/${event.value}` : ''}`

    let batteryLevel

    if (document.visibilityState !== 'hidden') {
        batteryLevel = await getBatteryLevel()
    }

    return {
        eventCategory: isWebPlatform ? trimByLength(event.eventCategory) : '',
        eventAction: trimByLength(eventAction, EVENT_ACTION_LENGTH),
        eventType,
        value: isWebPlatform ? trimByLength(event.value) : '',
        properties: prepareProperties(event.properties),
        batteryLevel,
        connectionType: getConnectionType(),
        timeStamp: options?.timeStamp || getISOTime(),
        ...url && { url: trimByLength(url) },
        ...pageName && { pageName: trimByLength(pageName) },
    }
}

export const getEventData = async (event: BaseItem, eventType: EventType, options?: EventDataOptions): Promise<RequestBody> => {
    const dataItem = await getData(event, eventType, options)
    const meta = getMeta()

    // Пакет с событием ожидает deviceId и sessionId, но если не передали, то он самостоятельно создаст информацию о них
    let deviceId = options?.deviceId
    let sessionId = options?.sessionId

    if (!deviceId) {
        deviceId = await getDeviceId()
    }
    if (!sessionId) {
        await setSessionId()
        sessionId = await getSessionId()
    }

    const profile = getProfile({
        sessionId,
        deviceId
    })

    return {
        profile,
        meta,
        data: [dataItem]
    }
}
