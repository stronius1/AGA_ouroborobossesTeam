const COMMON_DEFAULT_LENGTH = 255

export const trimByLength = (string = '', length = COMMON_DEFAULT_LENGTH): string => {
    return string.length > length ? string.substring(0, length) : string
}
