import type { Request } from '../helpers/send-package'

/**
 * Адаптер отправки событий на основе fetch
 * @param {String} config.url адрес запроса
 * @param {any} config.body тело запроса
 * @param {any} config.method http метод
 * @param {Boolean} config.credentials credentials для CORS и передачи cookie
 * @return {Promise} адрес запроса
 */
export const requestFetch: Request<any> = async ({ url, body, method = 'POST', credentials = false }) => {
    const fetchConfig: RequestInit = {
        method,
        body: body ? JSON.stringify(body) : void 0,
        keepalive: true,
        credentials: credentials ? 'include' : 'omit'
    }

    if (body) {
        fetchConfig.headers = {
            'Content-Type': 'application/json;charset=utf-8'
        }
    }

    try {
        const response = await fetch(url, fetchConfig)
        // eslint-disable-next-line @typescript-eslint/no-unsafe-return
        return await response.json()
    } catch (error: unknown) {
        return void 0
    }
}
