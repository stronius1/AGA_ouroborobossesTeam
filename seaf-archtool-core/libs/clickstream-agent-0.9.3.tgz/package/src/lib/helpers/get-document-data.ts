export const getCurrentURL = (): string | null => {
    if (!globalThis.document) {
        return null
    }

    const { location: { origin, pathname } } = globalThis.document
    return `${origin}${pathname.length > 1 ? pathname : ''}`
}

export const getCurrentTitle = (): string | null => {
    if (!globalThis.document) {
        return null
    }

    return globalThis.document.title
}
