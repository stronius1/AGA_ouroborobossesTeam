import { getRequestAdapter, getRestRequestAdapter } from './config/config-adapters'
import { getReportUrl } from './config/config'
import { getMeta } from './store/meta'
import { LOG_PREFIX } from './config/constants'

const addError = (messages: Array<string>, condition: boolean, message: string): void => {
    if (condition) {
        messages.push(message)
    }
}

export const checkErrors = (): void => {
    const messages: Array<string> = []

    addError(messages, !getReportUrl(), 'Не установлена конфигурация reportUrl. Используйте setConfig({ reportUrl }) для определения точки получения данных')
    addError(messages, !getMeta().apiKey, 'Не установлен ключ meta apiKey. Используйте setMeta({ apiKey }) для отправки данных по вашему продукту')
    addError(messages, !getRequestAdapter(), 'Не установлен сетевой адаптер. Используйте setConfig({ requestAdapter }) или preset() для установки сетевого адаптера отправки данных')
    addError(messages, !getRestRequestAdapter(), 'Не установлен сетевой адаптер. Используйте setConfig({ restRequestAdapter }) или preset() для установки сетевого адаптера аварийной отправки данных')

    if (messages.length) {
        messages.forEach((message) => {
            console.error(new Error(`${LOG_PREFIX} ${message}`))
        })
    }
}
