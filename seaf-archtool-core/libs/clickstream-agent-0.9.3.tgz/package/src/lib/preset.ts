import { changeUrlHandler } from './event-handlers/change-url'
import { hiddenTabHandler } from './event-handlers/hidden-tab'
import { warmUpSessionIdHandler } from './event-handlers/warm-up-session-id'
import { requestFetch } from './adapters/fetch'
import { setRequestAdapter, setRestRequestAdapter } from './config/config'
import { listenTechEvent } from './tech-event'
import { once } from './helpers/mantle/once'

/**
 * Предустановленные обработчики, адаптеры, слушатели, обязательные действия
 * @return {void}
 */
export const preset = once((): void => {
    setRequestAdapter(requestFetch)
    setRestRequestAdapter(requestFetch)
    listenTechEvent()
    warmUpSessionIdHandler()
    hiddenTabHandler()
    changeUrlHandler()
})
