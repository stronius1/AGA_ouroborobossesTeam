import { join } from 'path'
import { writeFileSync } from 'fs'
import { execSync } from 'child_process'

import packageJson from '../package.json'
import meta from '../src/lib/store/meta-config.json'

if (meta.sdkVersion !== packageJson.version) {
    meta.sdkVersion = packageJson.version

    try {
        // Записываем обновленный json файл
        writeFileSync(join(__dirname, '../src/lib/store/meta-config.json'), JSON.stringify(meta, null, 4))
        // Добавляем изменённый файл в индекс git
        execSync('git add ./src/lib/store/meta-config.json')
    } catch (error: unknown) {
        console.error('Ошибка при выполнении скрипта:', error)
    }
}

