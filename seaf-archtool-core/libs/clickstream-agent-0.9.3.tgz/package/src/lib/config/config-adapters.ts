import type { Request } from '../helpers/send-package'

let configRequestAdapter: Request
let configRestRequestAdapter: Request

/**
 * Переопределение сетевого адаптера для фоновой отправки метрик
 * @param {String} requestAdapter сетевой адаптер для фоновой отправки метрик
 * @return {void}
 */
export const setRequestAdapter = (requestAdapter: Request): void => {
    configRequestAdapter = requestAdapter
}
export const getRequestAdapter = (): Request => {
    return configRequestAdapter
}

/**
 * Переопределение сетевого адаптера для финальной отправки метрик
 * @param {String} requestAdapter сетевой адаптер для финальной отправки метрик
 * @return {void}
 */
export const setRestRequestAdapter = (requestAdapter: Request): void => {
    configRestRequestAdapter = requestAdapter
}
export const getRestRequestAdapter = (): Request => {
    return configRestRequestAdapter
}
