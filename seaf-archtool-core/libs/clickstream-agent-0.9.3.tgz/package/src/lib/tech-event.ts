import type { TechEvent } from './store/schedule-tech-events'
import { getEventData } from './store/get-event-data'
import { pushStorage } from './store/package-storage'
import { listen } from './helpers/event-bus'
import { once } from './helpers/mantle/once'

export const createTechEvent = async (config: TechEvent): Promise<void> => {
    if ('timeStamp' in config) {
        const eventData = await getEventData(
            {
                eventCategory: 'cs',
                value: '',
                eventAction: config.eventAction
            },
            'technical',
            {
                timeStamp: config.timeStamp,
                sessionId: config.sessionId,
                deviceId: config.deviceId
            }
        )

        pushStorage(eventData)

        delete config.timeStamp
    }
}

/**
 * Слушатель генерации tech-событий first_launch и start_session
 * @return {void}
 */
export const listenTechEvent = once(() => {
    listen(createTechEvent)
})
