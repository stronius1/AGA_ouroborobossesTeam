import '../global.types'

import { metaUpdater } from './store/meta'
import { setMeta } from './store/set-meta'
import { setProfile, profileUpdater } from './store/profile'
import { setDeviceId, getDeviceId } from './store/device-id'
import { setSessionId, deleteSessionId } from './store/session-id'
import {
    setReportUrl,
    setBufferSize,
    setDeviceIdUrl,
    setRequestAdapter,
    setRestRequestAdapter,
    setHashAlgorithm,
    setHashSalt,
    setSessionLifetime,
    setConfig
} from './config/config'
import { setUTMUrlParams } from './store/utm-params'
import { changeUrlHandler } from './event-handlers/change-url'
import { hiddenTabHandler } from './event-handlers/hidden-tab'
import { warmUpSessionIdHandler } from './event-handlers/warm-up-session-id'
import { handleUrlChange } from './helpers/handle-url-change'
import { requestBeacon } from './adapters/beacon'
import { requestXhr } from './adapters/xhr'
import { requestFetch } from './adapters/fetch'
import { sha256 } from './helpers/sha256'
import { preset } from './preset'
import { sendEvent, sendSensitiveEvent, sendTechEvent } from './event'
import { listenTechEvent } from './tech-event'

/**
 * Объявление объекта API globalThis.clickstream
 * @return {void}
 */
export const global = (): void => {
    if (!globalThis.clickstream) {
        globalThis.clickstream = {
            setMeta,
            metaUpdater,
            setProfile,
            profileUpdater,
            setDeviceId,
            getDeviceId,
            setSessionId,
            deleteSessionId,
            setReportUrl,
            setBufferSize,
            setDeviceIdUrl,
            setRequestAdapter,
            setRestRequestAdapter,
            setHashAlgorithm,
            setHashSalt,
            setSessionLifetime,
            setConfig,
            setUTMUrlParams,
            sendEvent,
            sendSensitiveEvent,
            sendTechEvent,
            listenTechEvent,
            changeUrlHandler,
            hiddenTabHandler,
            warmUpSessionIdHandler,
            handleUrlChange,
            preset,
            requestBeacon,
            requestXhr,
            requestFetch,
            sha256
        }
    }
}
