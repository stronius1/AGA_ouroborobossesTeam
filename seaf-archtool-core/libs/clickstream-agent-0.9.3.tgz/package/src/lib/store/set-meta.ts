import { trimByLength } from '../helpers/trim-by-length'

import { meta } from './meta'
import { updateExistingPackages } from './package-storage'
import { setSessionId } from './session-id'
import type { Meta } from './meta'

/**
 * Установка настроек мета-параметров для пакета событий
 * @param {Meta} nextMeta объект настроек мета-параметров
 * @return {void}
 */
export const setMeta = (nextMeta: Meta): void => {
    Object.assign(meta, {
        ...nextMeta,
        ...nextMeta.applicationName && { applicationName: trimByLength(nextMeta.applicationName) },
        ...nextMeta.deviceAbi && { deviceAbi: trimByLength(nextMeta.deviceAbi) },
        ...nextMeta.deviceMemorySize && { deviceMemorySize: trimByLength(nextMeta.deviceMemorySize) },
        ...nextMeta.deviceModel && { deviceModel: trimByLength(nextMeta.deviceModel) },
        ...nextMeta.deviceVendor && { deviceVendor: trimByLength(nextMeta.deviceVendor) },
        ...nextMeta.operationSystem && { operationSystem: trimByLength(nextMeta.operationSystem) },
        ...nextMeta.operationSystemVersion && { operationSystemVersion: trimByLength(nextMeta.operationSystemVersion) }
    })

    // Обновляем мету в уже сформированных пакетах
    updateExistingPackages({ meta })
    // Формируем сессионную куку с новым apiKey
    void setSessionId()
}
