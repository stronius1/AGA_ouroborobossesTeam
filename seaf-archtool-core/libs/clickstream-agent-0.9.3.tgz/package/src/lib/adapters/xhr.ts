import type { Request } from '../helpers/send-package'

const STATUS_FAIL = 400
const XHR_READY_STATE = 4

/**
 * Адаптер отправки событий на основе XMLHttpRequest
 * @param {String} config.url адрес запроса
 * @param {any} config.body тело запроса
 * @param {any} config.method http метод
 * @param {Boolean} config.credentials credentials для CORS и передачи cookie
 * @return {Promise} адрес запроса
 */
export const requestXhr: Request<any> = ({ url, body, method = 'POST', credentials = false }) => {
    return new Promise((resolve, reject) => {
        const xhr = new XMLHttpRequest()
        xhr.open(method, url, true)
        if (body) {
            xhr.setRequestHeader('Content-Type', 'application/json;charset=utf-8')
        }
        if (credentials) {
            xhr.withCredentials = true
        }

        xhr.send(body ? JSON.stringify(body) : body)

        /* comment: xhr built-in method */
        /* eslint-disable-next-line unicorn/prefer-add-event-listener */
        xhr.onreadystatechange = (): void => {
            if (xhr.readyState === XHR_READY_STATE) {
                if (xhr.status >= STATUS_FAIL) {
                    reject()
                } else {
                    try {
                        resolve(JSON.parse(xhr.response))
                    } catch (error) {
                        resolve(void 0)
                    }
                }
            }
        }
    })
}
