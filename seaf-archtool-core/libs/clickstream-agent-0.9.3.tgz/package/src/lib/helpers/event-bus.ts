import type { TechEvent } from '../store/schedule-tech-events'

type Listener = (config: TechEvent) => Promise<void>
const listeners: Array<Listener> = []

export const listen = (listener: Listener): void => {
    listeners.push(listener)
}
export const emit = (config: TechEvent): void => {
    listeners.forEach((listener) => {
        void listener(config)
    })
}
