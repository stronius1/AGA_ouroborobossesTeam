/* comment: объявление через let/const в globalThis не работает */
/* eslint-disable no-var */
/* comment: объявление через let/const в globalThis не работает */
/* eslint-disable vars-on-top */
import type { metaUpdater } from './lib/store/meta'
import type { setMeta } from './lib/store/set-meta'
import type { setProfile, profileUpdater } from './lib/store/profile'
import type { setDeviceId, getDeviceId } from './lib/store/device-id'
import type { deleteSessionId, setSessionId } from './lib/store/session-id'
import type {
    setReportUrl,
    setBufferSize,
    setDeviceIdUrl,
    setRequestAdapter,
    setRestRequestAdapter,
    setHashAlgorithm,
    setHashSalt,
    setConfig,
    setSessionLifetime,
} from './lib/config/config'
import type {
    sendEvent,
    sendSensitiveEvent,
    sendTechEvent,
} from './lib/event'
import type { listenTechEvent } from './lib/tech-event'
import type { handleUrlChange } from './lib/helpers/handle-url-change'
import type { changeUrlHandler } from './lib/event-handlers/change-url'
import type { hiddenTabHandler } from './lib/event-handlers/hidden-tab'
import type { warmUpSessionIdHandler } from './lib/event-handlers/warm-up-session-id'
import type { connectionTypes } from './lib/getters/get-connection-type'
import type { requestBeacon } from './lib/adapters/beacon'
import type { requestXhr } from './lib/adapters/xhr'
import type { requestFetch } from './lib/adapters/fetch'
import type { sha256 } from './lib/helpers/sha256'
import type { setUTMUrlParams } from './lib/store/utm-params'
import type { preset } from './lib/preset'

export interface Clickstream {
    setReportUrl: typeof setReportUrl
    setBufferSize: typeof setBufferSize
    setDeviceIdUrl: typeof setDeviceIdUrl
    setSessionLifetime: typeof setSessionLifetime
    setRequestAdapter: typeof setRequestAdapter
    setRestRequestAdapter: typeof setRestRequestAdapter
    setDeviceId: typeof setDeviceId
    getDeviceId: typeof getDeviceId
    setSessionId: typeof setSessionId
    deleteSessionId: typeof deleteSessionId
    setConfig: typeof setConfig
    setMeta: typeof setMeta
    setProfile: typeof setProfile
    sendEvent: typeof sendEvent
    sendSensitiveEvent: typeof sendSensitiveEvent
    sendTechEvent: typeof sendTechEvent
    listenTechEvent: typeof listenTechEvent
    changeUrlHandler: typeof changeUrlHandler
    hiddenTabHandler: typeof hiddenTabHandler
    warmUpSessionIdHandler: typeof warmUpSessionIdHandler
    setHashAlgorithm: typeof setHashAlgorithm
    setHashSalt: typeof setHashSalt
    setUTMUrlParams: typeof setUTMUrlParams
    metaUpdater: typeof metaUpdater
    profileUpdater: typeof profileUpdater
    requestBeacon: typeof requestBeacon
    requestXhr: typeof requestXhr
    requestFetch: typeof requestFetch
    sha256: typeof sha256
    handleUrlChange: typeof handleUrlChange
    preset: typeof preset
}

interface MicrosoftCrypto {
    getRandomValues: <T extends ArrayBufferView | null>(array: T) => T
}

declare global {
    var clickstream: Clickstream | undefined
    var msCrypto: MicrosoftCrypto | undefined

    interface Navigator {
        getBattery: <T>() => Promise<Record<string, T>>
        browserLanguage: string
        userLanguage: string
        systemLanguage: string
        connection?: {
            type?: keyof typeof connectionTypes
        }
    }
}
