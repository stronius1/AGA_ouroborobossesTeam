/* eslint-disable consistent-this */
/* eslint-disable @typescript-eslint/no-unsafe-assignment */
/* eslint-disable @typescript-eslint/no-explicit-any */

type Options = {
    maxWait?: number
    leading?: boolean
    trailing?: boolean
}

type Timeout = NodeJS.Timeout

/**
 * Полный дубль реализации [_.debounce](https://lodash.com/docs/4.17.15#debounce) с заменой некоторых примитивов
 */
export const debounce = <T extends (this: any, ...args: Array<any>) => any>(func: T, wait = 0, options: Options = {}) => {
    const {
        maxWait,
        leading = false,
        trailing = true
    } = options
    let lastArgs: Array<any> | undefined
    let lastContext: any
    let result: any
    let timerId: Timeout | undefined
    let lastCallTime: number | undefined
    let lastInvokeTime = 0
    const maxing = maxWait !== void ''
    
    function invokeFunc (time: number): any {
        const args = lastArgs
        const thisArg = lastContext
        
        lastArgs = void ''
        lastContext = void ''
        lastInvokeTime = time
        result = func.apply(thisArg, <Array<any>>args)

        return result
    }
    
    function shouldInvoke (time: number): boolean {
        const timeSinceLastCall = time - <number>lastCallTime
        const timeSinceLastInvoke = time - lastInvokeTime
        
        // Either this is the first call, activity has stopped and we're at the
        // trailing edge, the system time has gone backwards and we're treating
        // it as the trailing edge, or we've hit the `maxWait` limit.
        return (lastCallTime === void '' || (timeSinceLastCall >= wait) ||
            (timeSinceLastCall < 0) || (maxing && timeSinceLastInvoke >= maxWait))
    }
    
    function remainingWait (time: number): number {
        const timeSinceLastCall = time - <number>lastCallTime
        const timeSinceLastInvoke = time - lastInvokeTime
        const timeWaiting = wait - timeSinceLastCall
    
        return maxing
            ? Math.min(timeWaiting, maxWait - timeSinceLastInvoke)
            : timeWaiting
    }
    
    function trailingEdge (time: number): any {
        timerId = void ''
        
        // Only invoke if we have `lastArgs` which means `func` has been
        // debounced at least once.
        if (trailing && lastArgs) {
            return invokeFunc(time)
        }

        lastArgs = void ''
        lastContext = void ''

        return result
    }
    
    function timerExpired (): any | undefined {
        const time = Date.now()

        if (shouldInvoke(time)) {
            return trailingEdge(time)
        }
        
        timerId = setTimeout(timerExpired, remainingWait(time))

        return void ''
    }
    
    function leadingEdge (time: number): any {
        lastInvokeTime = time
        timerId = setTimeout(timerExpired, wait)
        return leading ? invokeFunc(time) : result
    }
    
    function cancel (): void {
        if (timerId !== void '') {
            clearTimeout(timerId)
        }
        lastInvokeTime = 0;
        lastArgs = void ''
        lastCallTime = void ''
        lastContext = void ''
        timerId = void ''
    }
    
    function flush (): any {
        return timerId === void '' ? result : trailingEdge(Date.now())
    }
    
    function debounced (this: any, ...args: Array<any>): any {
        const time = Date.now()
        const isInvoking = shouldInvoke(time)
        
        lastArgs = args
        lastContext = this
        lastCallTime = time
        
        if (isInvoking) {
            if (timerId === void '') {
                return leadingEdge(lastCallTime)
            }
            if (maxing) {
                timerId = setTimeout(timerExpired, wait)
                return invokeFunc(lastCallTime)
            }
        }
        if (timerId === void '') {
            timerId = setTimeout(timerExpired, wait)
        }
        return result
    }

    debounced.cancel = cancel
    debounced.flush = flush

    return debounced
}

/**
 * Полный дубль реализации [_.throttle](https://lodash.com/docs/4.17.15#throttle) с заменой некоторых примитивов
 */
export const throttle = <T extends (this: any, ...args: Array<any>) => any>(func: T, wait = 0, options: Options = {}) => {
    const {
        leading = true,
        trailing = true
    } = options
    
    return debounce(func, wait, {
        leading,
        maxWait: wait,
        trailing
    })
}
