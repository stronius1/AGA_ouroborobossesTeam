import type { Properties } from './property.types'

export type UpdatableEntity = { customIdentifiers?: Properties }

type UpdateCustomIdentifiers = (args: {
    entity: UpdatableEntity
    key: string
    value: string
}) => void

export const updateCustomIdentifiers: UpdateCustomIdentifiers = ({ entity, key, value }) => {
    if (!entity.customIdentifiers) {
        entity.customIdentifiers = []
    }

    const payload = {
        key,
        value
    }

    const currentSetting = entity.customIdentifiers.find((property) => {
        return property.key === key
    })

    if (currentSetting) {
        entity.customIdentifiers = entity.customIdentifiers.map((identifier) => {
            return identifier.key === key ? payload : identifier
        })
    } else {
        entity.customIdentifiers = [
            ...entity.customIdentifiers,
            payload
        ]
    }
}
