import { getUserIdentifiersStore } from '../config/config'
import { CUSTOM_SESSION_ID_KEY } from '../config/constants'
import { getISOTime } from '../getters/get-time-stamp'
import { emit } from '../helpers/event-bus'
import { makeSessionIdKey } from '../helpers/make-session-id-key'


export interface TechEvent {
    eventAction: string
    timeStamp?: string
    deviceId?: string
    sessionId?: string
}

export const firstLaunch: TechEvent = {
    eventAction: 'first_launch'
}
export const startSession: TechEvent = {
    eventAction: 'start_session'
}

export const scheduleFirstLaunchEvent = async (deviceId: string): Promise<void> => {
    firstLaunch.deviceId = deviceId
    startSession.deviceId = deviceId
    firstLaunch.timeStamp = getISOTime()

    // firstLaunch на работающую сессию (если меняемся между _sa и _sv)
    const userIdentifiersStore = getUserIdentifiersStore()
    const sessionId = await userIdentifiersStore.getData(CUSTOM_SESSION_ID_KEY) || await userIdentifiersStore.getData(makeSessionIdKey())
    if (sessionId) {
        firstLaunch.sessionId = sessionId
        emit(firstLaunch)
    }
}

export const scheduleStartSessionEvent = (sessionId: string): void => {
    firstLaunch.sessionId = sessionId
    startSession.sessionId = sessionId
    startSession.timeStamp = getISOTime()
    emit(firstLaunch)
    emit(startSession)
}
