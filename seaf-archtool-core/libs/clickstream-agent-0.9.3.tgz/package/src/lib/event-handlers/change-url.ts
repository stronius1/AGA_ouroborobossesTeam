import { flushFullStorage } from '../store/flush-full-storage'

/**
 * Обработчик смены URL документа (отмонтирования)
 * @return {void}
 */
export const changeUrlHandler = (): void => {
    globalThis.addEventListener?.('beforeunload', flushFullStorage)
}
