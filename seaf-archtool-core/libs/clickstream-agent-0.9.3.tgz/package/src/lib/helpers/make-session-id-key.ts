import { SESSION_ID_KEY } from '../config/constants'
import { getMeta } from '../store/meta'

export const makeSessionIdKey = (): string => {
    const { apiKey } = getMeta()

    return `${SESSION_ID_KEY}${apiKey ? `.${apiKey}` : ''}`
}
