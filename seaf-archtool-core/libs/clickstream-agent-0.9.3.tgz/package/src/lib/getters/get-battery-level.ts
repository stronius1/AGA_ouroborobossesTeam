export default async (): Promise<string | undefined> => {
    try {
        // comment: поддерживается не всеми браузерами
        // eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
        const battery = await globalThis.navigator?.getBattery<number>() || {}

        const { level } = battery

        if (typeof level === 'number') {
            return String(100 * level)
        }

        return void 0
    } catch (error: unknown) {
        return void 0
    }
}
