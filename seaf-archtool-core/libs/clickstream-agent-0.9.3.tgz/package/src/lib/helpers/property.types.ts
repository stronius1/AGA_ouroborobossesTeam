/**
 * Стандартная структура дополнительного параметра
 */
export type PropertyItem = {
    key: string
    value: string
}

export type PreparedProperties = Array<PropertyItem>

export type Properties = PreparedProperties | null
