import type { Properties, PreparedProperties } from './property.types'
import { trimByLength } from './trim-by-length'

const PROPERTY_ITEMS_LENGTH = 128

export const prepareProperties = (properties?: Properties): PreparedProperties | undefined => {
    if (properties === null || properties === void 0) {
        return void 0
    }

    const filteredProperties = properties
        .filter(({ value }) => {
            return typeof value === 'string'
        })
        .slice(0, PROPERTY_ITEMS_LENGTH)

    if (!filteredProperties.length) {
        return void 0
    }

    return filteredProperties.map(({ key, value }) => {
        return {
            key: trimByLength(key),
            value: trimByLength(value)
        }
    })
}
