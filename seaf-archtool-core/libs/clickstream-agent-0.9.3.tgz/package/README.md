# Clickstream Analytics SDK and Agent

## API clickstream agent

[Confluence](https://confluence.sberbank.ru/pages/viewpage.action?pageId=11604166115)


## Support

[Создать баг](https://jira.sberbank.ru/secure/CreateIssueDetails!init.jspa?pid=318800&issuetype=1&summary=%5Bclickstream-agent%5D%20&priority=4&customfield_18300=374293&description=%E2%98%9D%20%D0%9D%D0%B5%20%D0%B7%D0%B0%D0%B1%D1%83%D0%B4%D1%8C%20%D0%B7%D0%B0%D0%BF%D0%BE%D0%BB%D0%BD%D0%B8%D1%82%D1%8C%20%D0%A2%D0%B5%D0%BC%D1%83%20%D0%B2%D1%8B%D1%88%D0%B5%20%E2%98%9D%0D%0A%0D%0A%D0%9C%D0%B5%D1%81%D1%82%D0%BE%20%D0%BE%D0%B1%D0%BD%D0%B0%D1%80%D1%83%D0%B6%D0%B5%D0%BD%D0%B8%D1%8F%20(%D0%B1%D0%BB%D0%BE%D0%BA,%20%D0%BF%D0%BE%D0%BB%D1%8C%D0%B7%D0%BE%D0%B2%D0%B0%D1%82%D0%B5%D0%BB%D1%8C)%3A%0D%0A%D0%92%D0%B5%D1%80%D1%81%D0%B8%D1%8F%20%D0%B1%D0%B8%D0%B1%D0%BB%D0%B8%D0%BE%D1%82%D0%B5%D0%BA%D0%B8%3A%0D%0A%D0%9E%D0%BF%D0%B8%D1%81%D0%B0%D0%BD%D0%B8%D0%B5%3A%0D%0A)


## Migration

[Как мигрировать](./MIGRATION.md)


## Tree-shaking

В библиотеке указан массив файлов с side-effects, поэтому при включенном tree-shaking неиспользуемый код будет исключаться кроме объявления window.

## Agent (UMD / ESM)

В общем случае вам будет достаточно дефолтного импорта `@sbol/clickstream-agent`.
Если вы работаете с зависимостью как с UMD (например, через system.js или просто через статический файл) или как с ESM (собираете из файлов зависимости),
то вы получите все экспортируемые методы и предварительную настройку модуля. В нее входят:
* Предустановка сетевых адаптеров
* Объявление API в `globalThis.clickstream`
* Предустановка обработчиков закрытия/обновления и скрытия вкладки

## SDK (ESM)

Для более тонкой настройки агента существует отдельный импорт `@sbol/clickstream-agent/sdk`.
При импортах отсюда вы можете самостоятельно определить код, который должен войти в сборку.
Таким образом, исключаются заранее настроенные адаптеры, обработчики и объявление API в `globalThis.clickstream`.

## Поддержка

### Package exports

SDK поддерживает [package exports](https://nodejs.org/api/packages.html#package-entry-points). Данный API поддерживается, например `webpack@5`.
Если подобной поддержки у вас нет, то импорты вида `@sbol/clickstream-agent/es5` стоит заменить, например, на `@sbol/clickstream-agent/dist/es5/cjs`.

### ES5

Мы поддерживаем работу IE для СБОЛ.ПРО.
Сборка комплируется в папку `dist/es5` и доступна по импорту `@sbol/clickstream-agent/es5`.

### ES8

Мы поддерживаем работу браузеров большой аудитории клиентов СБОЛ.
Сборка комплируется в папку `dist/es8` и доступна по импорту `@sbol/clickstream-agent/es8`.

### ESNEXT

Сборка также по дефолту предоставляется в самой актуальной спецификации ES.
Сборка комплируется в папку `dist` и доступна по импорту `@sbol/clickstream-agent`.

### ESM

Модули, работающие в ES Modules, могут получить желаемые версии библиотеки в поддиректориях `/esm`.

### CJS

Модули, не способные преобразовать ES Modules в CommonJS, могут получить желаемые версии библиотеки в поддиректориях `/cjs`.

### UMD

Модули, желающие работать с агентом как с вендорным скриптом (по подключению через тег script или AMD), могут получить желаемый скрипт в поддиректориях `/umd`.


## Network Adapters

Вы можете установить свой сетевой адаптер для отправки объекта метрик.

Для этого передайте в методы `setRequestAdapter` и `setRestRequestAdapter` желаемые сетевые адаптеры.

* `requestAdapter` – будет выполнять отправку данных в обычном состоянии агента
* `restRequestAdapter` – будет выполнять отправку данных в критической ситуации (например, при обновлении страницы или закрытии вкладки)

В качестве адаптеров выступают функции, удовлетворяющие экспортируемому типу `Request`.
В библиотеке реализовано 3 дефолтных native адаптера:

* `requestXhr` – на базе `XMLHttpRequest`
* `requestFetch` – на базе `fetch`
* `requestBeacon` – на базе `sendBeacon`, обратите внимание, что у него нет обработки ошибок и требуется обработка CORS, следовательно данные могут быть не доставлены

### Custom Network Adapters

Возьмем, например, библиотеку axios. Реализуем адаптер для нее:
```
import axios from 'axios'

export const requestAxios: Request = ({ url, body, method }) => {
    return axios({
        method,
        url,
        data: body
    })
}
```

### Custom deviceId / sessionId Store

Из коробки deviceId и sessionId сохраняются в cookie браузера. В некоторых случаях может потребоваться сохранить их в другм месте.
Для этого надо будет написать свою реализацию интерфейса userIdentifiersStore из ../store/user-identifiers-store (там есть подробная документация на интерфейс)

```
const userIdentifiersStoreOwn = {
  
    getData(name: string): Promise<string | undefined> {
      // TODO: тут необходимо получить значение по ключу из вашего хранилища и вернуть, undefined если пары ключ-значение не найдено
    },
  
    setData(name: string, value: string, ms: number): Promise<void> {
      // TODO: тут необходимо сохранить пару ключ-значение в свое хранилище, ms указывает на то, через сколько значение должно инвалидироваться
      //       например сессия, которая живет несколько минут
    },
  
    deleteData(name: string): Promise<void> {
      // TODO: тут необходимо удалить пару ключ-значение из своего хранилища по ключу
    }
  }
```

переопределение поведения производится через setConfig

```
    setConfig({
        userIdentifiersStore: userIdentifiersStoreOwn
    })
```

## Тестирование и сборка

Сборка Вашего модуля с интегрированным SDK-clickstream может в pipeline делать fetch-запрос на https://visor.sberbank.ru/get. Например, в unit-тестах на jest или на других фреймворках (next и тп).
К сожалению, от этого запроса никак не избавиться, так как это часть кода SDK-агента.
Вызов не будет крашить сборку, но для тестов лучше целиком замокать модуль clickstream-agent.
