export const isEqual = <T extends object, R extends object>(objectTarget: T, objectSource: R): boolean => {
    return JSON.stringify(objectTarget) === JSON.stringify(objectSource)
}
