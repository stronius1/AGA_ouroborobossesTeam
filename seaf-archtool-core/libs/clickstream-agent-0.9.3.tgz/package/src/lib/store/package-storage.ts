import { getISOTime } from '../getters/get-time-stamp'
import { sendPackage } from '../helpers/send-package'
import { getBufferSize } from '../config/config'
import { isEqual } from '../helpers/is-equal'
import { INACTIVITY_TIMEOUT } from '../config/constants'
import { updatePackageSessionId } from '../helpers/update-package-session-id'
import type { RequestBody } from '../helpers/send-package'

/**
* Массив событий в пакете
*/
export type PackageStorage = Array<RequestBody | RequestBody>

export const packageStorage: PackageStorage = []

const isSameAdditionalData = (
    {
        meta: { timeStamp: timeStampA, ...restMetaA },
        profile: profileA
    }: RequestBody,
    {
        meta: { timeStamp: timeStampB, ...restMetaB },
        profile: profileB
    }: RequestBody
): boolean => {
    return isEqual(restMetaA, restMetaB) && isEqual(profileA, profileB)
}

const joinPackage = (pkg: RequestBody, item: RequestBody): void => {
    pkg?.data.push(item.data[0])
    // Время пересборки пакета обновлено
    pkg.meta.timeStamp = getISOTime()
}

const addPackage = (pkg: RequestBody): void => {
    packageStorage.push(pkg)
}

export const updateExistingPackages = ({ meta, profile }: Partial<RequestBody>): void => {
    if (!packageStorage.length) {
        return
    }

    if (meta) {
        packageStorage.forEach((pack) => {
            Object.assign(pack.meta, meta)
        })

    }

    if (profile) {
        packageStorage.forEach((pack) => {
            Object.assign(pack.profile, profile)
        })
    }
}

export const flushStorage = (full = false): void => {
    while (packageStorage.length > Number(!full)) {
        const pkg = packageStorage.shift()

        if (pkg) {
            void updatePackageSessionId(pkg)
                .then(() => {
                    return sendPackage(pkg)
                })
                .catch((error: Error) => {
                    // Ввиду асинхронности данного кода, сперва выполнится весь while,
                    // а только потом неудачные пакеты вернутся в хранилище
                    packageStorage.unshift(pkg)
                    /* comment: Вывод ошибки в консоль */
                    /* eslint-disable-next-line no-console */
                    console.error(error)
                })
        }
    }
}


let timerId: NodeJS.Timeout | undefined

const flushStorageByTimeout = (): void => {
    if (timerId) {
        clearTimeout(timerId)
    }

    timerId = setTimeout(() => {
        flushStorage(true)
    }, INACTIVITY_TIMEOUT)
}

export const pushStorage = (nextItem: RequestBody): void => {
    const lastItem = packageStorage[packageStorage.length - 1]

    if (!lastItem || lastItem.data.length >= getBufferSize() || !isSameAdditionalData(lastItem, nextItem)) {
        // Хранилище пустое, добавляем пакет
        // Буфер заполнен или изменились сопровождающие данные, добавляем пакет
        addPackage(nextItem)
    } else {
        // Пакет еще можно пополнить
        joinPackage(lastItem, nextItem)
    }

    const nextLastItem = packageStorage[packageStorage.length - 1]

    if (nextLastItem && nextLastItem.data.length >= getBufferSize()) {
        // Пакет заполнился, отправляем все
        flushStorage(true)
    } else if (packageStorage.length > 1) {
        // Если есть очередь, то сразу отправляем все, что есть до последнего запроса
        flushStorage()
    } else {
        // Запускаем таймер отправки пакета через 10 секунд
        flushStorageByTimeout()
    }
}
