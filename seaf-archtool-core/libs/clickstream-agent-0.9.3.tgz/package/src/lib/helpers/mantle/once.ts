/**
 * Используйте данную функцию для разового вызова функции
 */
export function once (fn: (...args: Array<any>) => void) {
    let called = false

    return function onced (this: any, ...args: Array<any>): void {
        if (!called) {
            called = true
            fn.apply(this, args)
        }
    }
}
