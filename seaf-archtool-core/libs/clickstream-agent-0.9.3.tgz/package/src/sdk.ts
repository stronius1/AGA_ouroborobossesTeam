export { metaUpdater } from './lib/store/meta'
export { setMeta } from './lib/store/set-meta'
export { setProfile, profileUpdater } from './lib/store/profile'
export type { Meta } from './lib/store/meta'
export type { Profile } from './lib/store/profile'
export { setDeviceId, getDeviceId } from './lib/store/device-id'
export { setSessionId, deleteSessionId } from './lib/store/session-id'
export {
    setReportUrl,
    setBufferSize,
    setDeviceIdUrl,
    setRequestAdapter,
    setRestRequestAdapter,
    setHashAlgorithm,
    setHashSalt,
    setSessionLifetime,
    setConfig
} from './lib/config/config'
export type { Config } from './lib/config/config'
export { setUTMUrlParams } from './lib/store/utm-params'
export { sendEvent, sendSensitiveEvent, sendTechEvent } from './lib/event'
export { listenTechEvent } from './lib/tech-event'
export { changeUrlHandler } from './lib/event-handlers/change-url'
export { hiddenTabHandler } from './lib/event-handlers/hidden-tab'
export { warmUpSessionIdHandler } from './lib/event-handlers/warm-up-session-id'
export { handleUrlChange } from './lib/helpers/handle-url-change'
export { preset } from './lib/preset'
export { global } from './lib/global'

export type { RequestBody, Request } from './lib/helpers/send-package'
export type { PropertyItem } from './lib/helpers/property.types'
export type { BaseItem } from './lib/event'

// adapters
export { requestBeacon } from './lib/adapters/beacon'
export { requestXhr } from './lib/adapters/xhr'
export { requestFetch } from './lib/adapters/fetch'

// hash algorithm
export { sha256 } from './lib/helpers/sha256'

// Clickstream API
export * from './global.types'
