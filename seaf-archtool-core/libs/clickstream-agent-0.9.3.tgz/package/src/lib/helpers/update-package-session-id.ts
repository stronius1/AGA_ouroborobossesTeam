import { getUserIdentifiersStore } from '../config/config'
import { SESSION_ID_KEY } from '../config/constants'

import { makeSessionIdKey } from './make-session-id-key'
import type { RequestBody } from './send-package'

export const updatePackageSessionId = async (pkg: RequestBody): Promise<void> => {
    const userIdentifiersStore = getUserIdentifiersStore()
    const storedSessionId = await userIdentifiersStore.getData(makeSessionIdKey())
    const emptySessionId = await userIdentifiersStore.getData(SESSION_ID_KEY)

    if (
        storedSessionId &&
        storedSessionId !== emptySessionId &&
        pkg.profile.sessionId === emptySessionId
    ) {
        pkg.profile.sessionId = storedSessionId
    }
    return void 0
}
