export const LOG_PREFIX = '[Clickstream Agent]'

export const WARM_UP_THROTTLE_TIMEOUT = 5000
export const INACTIVITY_TIMEOUT = 10000

export const WARM_UP_EVENT_TYPES = [
    'click',
    'touch',
    'keydown',
    'scroll'
] as const

export const PROFILE_COOKIE_NAMES = [
    '_ga',
    '_ym_uid',
    'top100_id',
    'tmr_lvid',
    '___dmpkit___',
] as const

export const UNHASHABLE_IDS = [
    'staticId',
    'idfa',
    'gaid'
]

export const DEVICE_ID_URL = 'https://visor.sberbank.ru/get'

export const SESSION_ID_KEY = '_sas'
export const CUSTOM_SESSION_ID_KEY = '_sas_custom'
