/**
 * @deprecated Метод определения отслеживаемых внешних и внутренних UTM-меток
 * @param {Array<String>} config.external имена параметров внешних UTM-меток для добавления в события
 * @return {void}
 */
export const setUTMUrlParams = (config: { external?: Array<string>; internal?: Array<string> }): void => {}
