export default (): string => {
    return globalThis.navigator?.userAgent
}
