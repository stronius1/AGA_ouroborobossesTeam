import { describe, it, expect } from '@jest/globals'

import { trimByLength } from '../trim-by-length'

const DEFAULT_LABEL = 'Кредитный потенциал/Успешный расчет'
const TEST_LENGTH = 32

describe('Модуль аналитики :: утилиты :: trimByLength', () => {
    it('Параметр короче ограничения по дефолту', () => {
        expect(trimByLength(DEFAULT_LABEL))
            .toBe(DEFAULT_LABEL)
    })
    it('Пустая строка', () => {
        expect(trimByLength('')).toBe('')
    })
    it('Пустой параметр', () => {
        expect(trimByLength()).toBe('')
    })
    it('Параметр с ограничением в 32 символа', () => {
        expect(trimByLength(DEFAULT_LABEL, TEST_LENGTH))
            .toBe('Кредитный потенциал/Успешный рас')
        expect(trimByLength(DEFAULT_LABEL, TEST_LENGTH).length).toBe(TEST_LENGTH)
    })
})
