import type { Request } from '../helpers/send-package'

/**
 * Адаптер отправки событий на основе sendBeacon
 * @param {String} config.url адрес запроса
 * @param {any} config.body тело запроса
 * @return {Promise} адрес запроса
 */
export const requestBeacon: Request<void> = ({ url, body }) => {
    return new Promise<void>((resolve, reject) => {
        const payload = new Blob([JSON.stringify(body)], {
            type: 'application/json;charset=utf-8'
        })

        const beacon = navigator.sendBeacon(url, payload)

        if (beacon) {
            resolve()
        } else {
            reject()
        }
    })
}
