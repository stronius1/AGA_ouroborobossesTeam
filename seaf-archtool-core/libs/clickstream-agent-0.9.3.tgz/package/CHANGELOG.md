### 0.9.3 (2025-10-06)

##### Bug Fixes

* **profile:**  [CLICKSPROD-1129] - Убрали лишнее декодирование URL параметров ([e64b40590eb](https://stash.sigma.sbrf.ru/projects/PLSBOL-LIBS/repos/clickstream-agent/commits/e64b40590eb0269c2acc6602d5b7b441f337b332))

### 0.9.2 (2025-09-05)

##### Bug Fixes

* **profile:**  [CLICKSPROD-1025] - заменили установку sberClientId на sbClientId ([9728d717cd2](https://stash.sigma.sbrf.ru/projects/PLSBOL-LIBS/repos/clickstream-agent/commits/9728d717cd25b0563b3fbb9f28a007517ba8981e))

### 0.9.1 (2025-08-04)

* **SDK**  Update version in meta-config file

### 0.9.0 (2025-07-22)

* **SDK**  [ERA-1167] - Добавили возможность переопределить место хранения deviceId и sessionId ([e1ab80d6fc6](https://stash.sigma.sbrf.ru/projects/PLSBOL-LIBS/repos/clickstream-agent/commits/e1ab80d6fc62011e0d677cc7b31406d095342b9d))

* **SDK**  [CLICKSPROD-787] - Добавили новые параметры в meta и profile, а тажке возможнось переопределять платформу ([907f31e9646](https://stash.sigma.sbrf.ru/projects/PLSBOL-LIBS/repos/clickstream-agent/commits/907f31e9646f15bcfaa10280ba4577da542519f2))

#### 0.8.15 (2025-02-28)

* **events:**  [CLICKSPROD-335] - Отправляем версию агента в meta.sdkVersion ([cb7c24d61b8](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/cb7c24d61b8fb299430f16e08c29108b40b674e0))

* **SDK**  [CLICKSPROD-319] - Добавили обработку ошибок в sendPackage ([2963b3a24f9](https://stash.sigma.sbrf.ru/projects/PLSBOL-LIBS/repos/clickstream-agent/commits/2963b3a24f9c2815797dc9035a9955cf357c3f092))

#### 0.8.14 (2025-01-13)

##### Bug Fixes

* **events:**  [CLICKSPROD-244] - Исправление логирование URL события ([209ad58485f](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/209ad58485fcbc85ca0459b9eb2f11fdea27bca6))

#### 0.8.13 (2024-11-22)

##### New Features

 * **events:**  [DBPFBI-5602] - уникальная сессия для каждого канала ([494688d74a7](https://stash.sigma.sbrf.ru/projects/PLSBOL-LIBS/repos/clickstream-agent/commits/494688d74a7e2e16912a7d6efb3a2520c2237a7b))

#### 0.8.12 (2024-09-26)

* **SDK**  [DBPFBI-5656] - куки _sas и _sv теперь работают на http доменах ([47f821ab0ef](https://stash.sigma.sbrf.ru/projects/PLSBOL-LIBS/repos/clickstream-agent/commits/47f821ab0ef374d9964c6ab9db1129b0e1340d82))

##### Bug Fixes

#### 0.8.11 (2024-09-16)

#### 0.8.10 (2024-08-20)

##### New Features

* **events:**  [DBPFBI-5304] - отправка очереди событий по времени бездействия пользователя ([3e19264c97f](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/https://stash.sigma.sbrf.ru/projects/PLSBOL-LIBS/repos/clickstream-agent/commits/3e19264c97f015da258899fbd21557a6ade89b97))

##### Bug Fixes

* **meta:**  [DBPFBI-5383] - Исправление потери настроек meta и profile в части событий ([0bded69c964](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/0bded69c964f765c939dd776a1d2e6cfaf758077))

#### 0.8.9 (2024-07-03)

#### 0.8.7 (2024-06-03)

#### 0.8.5 (2024-05-08)

##### Bug Fixes

* **cycle imports:**  [WDPC-523] Исправлены циклические импорты и добавлена проверка на них ([e0dac97e](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/e0dac97e2fed76e3479f6e665e2f2ec8d0539141))

##### Other Changes

* **cycle imports:**  [WDPC-523] Исправлены циклические импорты и добавлена проверка на них ([c3a74048](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/c3a740487e45ec9d06554894cf87862f27a790b0))

#### 0.8.4 (2024-03-27)

##### Bug Fixes

* **adapters:**  [WDPC-3] Не всегда есть json для парсинга и его возврата, try catch обертки ([4c4005bc](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/4c4005bc474e0c71cbf6b7ab7337a7855f782582))

#### 0.8.3 (2024-03-25)

##### Bug Fixes

* **ts,adapters:**  [WDPC-3] Исправлены перепутанные вызовы requestAdapter (и rest) ([2ce7e08a](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/2ce7e08a085cab6a348f8e8d9632e2e7e31abac1))

##### Other Changes

* **ts,adapters:**  [WDPC-3] Исправлены перепутанные вызовы requestAdapter (и rest) ([83f84f84](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/83f84f84ad569b3b40cfbe4101c42fe73e703e81))

#### 0.8.2 (2024-03-19)

##### New Features

* **deviceid:**  [WDPC-439] Сохраняем в домен _sv из тела запроса для кроссдоменности ([6bed98bd](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/6bed98bdb46e4ca5f7fd79d32f874f576c067c04))

##### Other Changes

* **deviceid:**  [WDPC-439] Сохраняем в домен _sv из тела запроса для кроссдоменности ([3f4cc50c](ssh://git@stash.sigma.sbrf.ru:7999/plsbol-libs/clickstream-agent.git/commit/3f4cc50cd7a67456cf0ee90aeef4313295e89e51))

### 0.8.0 (2024-03-13)

#### 0.7.4 (2024-03-12)

