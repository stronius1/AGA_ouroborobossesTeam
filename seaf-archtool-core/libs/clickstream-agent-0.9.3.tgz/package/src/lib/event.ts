import { pushStorage } from './store/package-storage'
import { sendPackage } from './helpers/send-package'
import { checkErrors } from './check-errors'
import { getEventData } from './store/get-event-data'
import type { Properties } from './helpers/property.types'

type EventType = 'technical' | 'sensitive' | 'business'

/**
 * Структура business-события
 */
export interface BaseItem {
    /**
   * Канал, в который отправляется событие, и приложение в канале, разделяется символом "_"
   * Длина строки не должна превышать 254 символа (+ 1 символ резерв для "_")
   */
    eventCategory: string
    /** Событие. Для поддержания вложенности событий разделяется символом "/" */
    eventAction: string
    /** Значение события. Длина строки не должны превышать 255 символов */
    value: string
    /**
   * Массив объектов, пар key:value, дополнительных параметров
   * В объекте не более 64 пар key:value
   * Название key не должно превышать 255 символов
   * Значение value не должно превышать 255 символов
   */
    properties?: Properties
}

export interface BaseTypedItem extends BaseItem {
    eventType: EventType
}

export interface EventItem extends BaseTypedItem {
    /**
   * Уровень заряда устройства на момент генерации события
   */
    batteryLevel?: string
    /**
   * Тип интернет-соединения устройства на момент генерации события
   */
    connectionType?: string
    /**
   * Время генерации события
   */
    timeStamp: string
    /**
   * Набор внутренних маркетинговых параметров URL
   */
    itm?: Properties
    /** Полный URL без search параметров и хэша, limit 255 */
    url?: string
    /** Название вкладки (document.title), limit 255 */
    pageName?: string
}

const pushEvent = async (event: BaseItem, eventType: EventType, immediately = false): Promise<void> => {
    const eventData = await getEventData(event, eventType)

    checkErrors()

    if (immediately) {
        void sendPackage(eventData).catch((error: Error) => {
            /* comment: Вывод ошибки в консоль */
            /* eslint-disable-next-line no-console */
            console.error(error)
        })
    } else {
        pushStorage(eventData)
    }
}

/**
 * Отправка бизнес события
 * @param {BaseItem} event объект события
 * @return {void}
 */
export const sendEvent = async (event: BaseItem): Promise<void> => {
    await pushEvent(event, 'business')
}

/**
 * Отправка технического события
 * @param {BaseItem} event объект события
 * @return {void}
 */
export const sendTechEvent = async (event: BaseItem): Promise<void> => {
    await pushEvent(event, 'technical')
}

/**
 * Отправка чувсвительного к данным события
 * @param {BaseItem} event объект события
 * @return {void}
 */
export const sendSensitiveEvent = async (event: BaseItem): Promise<void> => {
    await pushEvent(event, 'sensitive', true)
}
