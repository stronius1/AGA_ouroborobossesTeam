import { UNHASHABLE_IDS } from '../config/constants'
import getBrowser from '../getters/get-browser'
import getLanguage from '../getters/get-language'
import { getISOTime } from '../getters/get-time-stamp'
import { HashableUpdater, hashByConfig, HashableUpdaterByKey } from '../helpers/hash-by-config'
import { Properties } from '../helpers/property.types'
import { updateCustomIdentifiers } from '../helpers/update-custom-identifiers'

import metaConfig from './meta-config.json'

/**
 * Структура настроек мета-информации для пакета событий
 */
export interface Meta {
    /**
    * Уникальный ключ партнера/продукта
    */
    apiKey?: string
    /**
    * Application name
    */
    applicationName?: string
    /**
    * Device architecture
    */
    deviceAbi?: string
    /**
    * Device memory size
    */
    deviceMemorySize?: string
    /**
    * Device model
    */
    deviceModel?: string
    /**
    * Device manufacturer
    */
    deviceVendor?: string
    /**
    * Operation system of the device
    */
    operationSystem?: string
    /**
    * Operation system version of the device
    */
    operationSystemVersion?: string
    /**
    * Константа WEB, идентифицирует метрику на сервере (default WEB)
    */
    platform?: 'WEB' | 'MOBILE'
    /**
    * Версия clickstream-agent'a
    */
    sdkVersion?: string
}

/**
* Блок данных о приложении, устройстве и пакете отправленных данных
*/
export interface FilledMeta extends Meta {
    /**
   * User-Agent
   */
    browser?: string
    /**
     * Набор дополнительных идентификаторов
     */
    customIdentifiers?: Properties
    /**
   * Размер экрана на момент отправки пакета в виде `${width}x${height}`
   */
    screenSize?: string
    /**
   * Язык ОС
   */
    systemLanguage?: string
    /**
   * Время отправки пакета
   */
    timeStamp?: string
}

export const meta: FilledMeta = metaConfig as Meta

interface MetaUpdater {
    setSbAppID: HashableUpdater<this>
    setMetaID: HashableUpdaterByKey<this>
}

/**
 * Совокупность методов установки специфичных параметров мета-параметров
 */
export const metaUpdater: MetaUpdater = {
    /**
     * Установка SbAppId
     * @param {String} value значение SbAppID
     * @param {Boolean} enableHash признак хэширования
     * @return {MetaUpdater} metaUpdater
     */
    setSbAppID (value, enableHash) {
        updateCustomIdentifiers({
            entity: meta,
            key: 'sbApplicationId',
            value: hashByConfig(value, enableHash)
        })
        return this
    },
    /**
     * Установка значения некоторого идентификатора в meta
     * @param {String} key ключ идентификатора
     * @param {String} value значение идентификатора
     * @param {Boolean} enableHash признак хэширования. Для staticId, idfa, gaid всегда нет хеширования
     * @return {MetaUpdater} metaUpdater
     */
    setMetaID (key, value, enableHash) {
        updateCustomIdentifiers({
            entity: meta,
            key,
            value: hashByConfig(value, UNHASHABLE_IDS.includes(key) ? false : enableHash)
        })
        return this
    }
}

export const getMeta = (): FilledMeta => {
    return {
        ...meta,
        screenSize: globalThis.screen ? `${globalThis.screen.width}x${globalThis.screen.height}` : void 0,
        browser: getBrowser(),
        systemLanguage: getLanguage(),
        timeStamp: getISOTime()
    }
}
