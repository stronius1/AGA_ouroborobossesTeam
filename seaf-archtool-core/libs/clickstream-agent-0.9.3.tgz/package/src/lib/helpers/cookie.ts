const SECOND_BRACKET_GROUP = 2
const SUBDOMAIN_DEPTH = 2
const HTTPS_PROTOCOL = 'https:'

const getSecondLevelDomain = (): string => {
    const parts = globalThis.location.hostname.split('.')
    if (parts.length >= SUBDOMAIN_DEPTH) {
        return parts.slice(-SUBDOMAIN_DEPTH).join('.')
    }
    return globalThis.location.hostname
}

export const setCookie = (name: string, value: string, ms?: number): void => {
    if (typeof globalThis.document?.cookie === 'string') {
        const params = [
            `${name}=${value || ''}`,
            'samesite=strict',
            'path=/'
        ]

        // Проверка hostname на наличие уровней (точка) и top level domain (не цифровой)
        if (/\.[^\d]/.test(globalThis.location.hostname)) {
            params.push(`domain=.${getSecondLevelDomain()}`)

            if (globalThis.location.protocol === HTTPS_PROTOCOL) {
                params.push('secure')
            }
        }

        if (ms) {
            const date = new Date()
            date.setTime(date.getTime() + ms)
            params.push(`expires=${date.toUTCString()}`)
        }

        globalThis.document.cookie = params.join(';')
    }
}

export const getCookie = (name: string): string | undefined => {
    if (typeof globalThis.document?.cookie === 'string') {
        const regexp = new RegExp(`(^|[^;]+)\\s*${name}\\s*=\\s*([^;]+)`)
        const cookieValue = regexp.exec(globalThis.document.cookie)
        return cookieValue ? cookieValue[SECOND_BRACKET_GROUP] : void ''
    }

    return void ''
}

export const deleteCookie = (name: string): void => {
    setCookie(name, '', -1)
}
