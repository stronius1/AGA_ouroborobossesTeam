export const connectionTypes = {
    bluetooth: 'BLUETOOTH',
    cellular: 'CELLULAR',
    ethernet: 'ETHERNET',
    wifi: 'WIFI',
    mixed: 'UNKNOWN',
    none: 'UNKNOWN',
    wimax: 'UNKNOWN',
    other: 'UNKNOWN',
    unknown: 'UNKNOWN'
} as const

// comment: navigator.connection поддерживается не всеми браузерами
// eslint-disable-next-line @typescript-eslint/no-unnecessary-condition
export default (): string => {
    return connectionTypes[globalThis.navigator?.connection?.type ?? 'unknown']
}
