const ALIGNMENT = 10
const MINUTES_IN_HOUR = 60
const MS_IN_SECOND = 1000
const SECONDS_IN_MINUTE = 60
const MS_IN_MINUTE = SECONDS_IN_MINUTE * MS_IN_SECOND

const padStart = (value: number): number | string => {
    return value < ALIGNMENT ? `0${value}` : value
}

const formatOffset = (offset: number): string => {
    return `${
        offset < 0 ? '+' : '-'
    }${
        padStart(Math.abs(Math.floor(offset / MINUTES_IN_HOUR)))
    }:${
        padStart(Math.abs(offset % MINUTES_IN_HOUR))
    }`
}

export const getISOTime = (): string => {
    const date = new Date()
    const correctedDate = new Date(date.valueOf() - (date.getTimezoneOffset() * MS_IN_MINUTE))
    const [correctedShortDate] = correctedDate.toISOString().split('Z')
    return `${correctedShortDate}${formatOffset(correctedDate.getTimezoneOffset())}`
}

export const getTimestamp = (): number => {
    return Math.floor(new Date().getTime() / MS_IN_SECOND)
}
