import { setSessionId } from '../store/session-id'
import { WARM_UP_EVENT_TYPES, WARM_UP_THROTTLE_TIMEOUT } from '../config/constants'
import { throttle } from '../helpers/mantle/debounce'

/**
 * Обработчик прогрева сессии
 * @return {void}
 */
export const warmUpSessionIdHandler = (): void => {
    const throttledSetSessionId = throttle(() => {
        void setSessionId()
    }, WARM_UP_THROTTLE_TIMEOUT, { trailing: false, leading: true })

    WARM_UP_EVENT_TYPES.forEach((eventType) => {
        globalThis.document?.addEventListener(eventType, throttledSetSessionId)
    })
}
