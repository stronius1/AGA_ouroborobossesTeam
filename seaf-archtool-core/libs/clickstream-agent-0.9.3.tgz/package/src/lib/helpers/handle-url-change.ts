import { getEventData } from '../store/get-event-data'
import { pushStorage } from '../store/package-storage'

/**
 * Генератор tech-события screen_view с заданным параметром url
 * @param {String} url адрес страницы, сопровождающий screen_view событие
 * @return {void}
 */
export const handleUrlChange = async (url: string): Promise<void> => {
    const eventData = await getEventData(
        {
            eventCategory: 'cs',
            value: '',
            eventAction: 'screen_view'
        },
        'technical',
        {
            url
        }
    )

    pushStorage(eventData)
}
