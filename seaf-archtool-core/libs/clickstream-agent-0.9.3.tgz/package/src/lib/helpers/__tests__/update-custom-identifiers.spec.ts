import { describe, it, expect } from '@jest/globals'

import { UpdatableEntity, updateCustomIdentifiers } from '../update-custom-identifiers'

describe('Модуль аналитики :: утилиты :: updateCustomIdentifiers', () => {
    it('Обновление customIdentifiers поля сущностей Meta и Profile', () => {
        const entity: UpdatableEntity = {}
        const resultFirstUpdate: UpdatableEntity = {
            customIdentifiers: [{ key: 'test', value: 'test' }]
        }
        const resultSecondUpdate:UpdatableEntity = {
            customIdentifiers: [{ key: 'test', value: 'test1' }]
        }

        updateCustomIdentifiers({
            entity,
            key: 'test',
            value: 'test'
        })

        expect(entity).toStrictEqual(resultFirstUpdate)

        updateCustomIdentifiers({
            entity,
            key: 'test',
            value: 'test1'
        })

        expect(entity).toStrictEqual(resultSecondUpdate)
    })
})
